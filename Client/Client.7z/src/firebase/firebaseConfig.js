// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAgacLbFO0UUII7SX_COA6tTgDCJh5MyIU",
  authDomain: "laura-vargas-7f3ad.firebaseapp.com",
  projectId: "laura-vargas-7f3ad",
  storageBucket: "laura-vargas-7f3ad.appspot.com",
  messagingSenderId: "658315611360",
  appId: "1:658315611360:web:56f139b3d2af20fb13d485"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export default app

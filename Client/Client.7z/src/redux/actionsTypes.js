export const GET_USER = "GET_USER";
export const GET_USERS = "GET_USERS";
export const GET_USER_ID = "GET_USER_ID";
export const GET_BRANCHES = "GET_BRANCHES";
export const GET_SPECIALTIES = "GET_SPECIALTIES";
export const GET_ROLES = "GET_ROLES";
export const ERROR = "ERROR";
export const DELETE_USER = "DELETE_USER"
export const SET_ICON = "SET_ICON"




